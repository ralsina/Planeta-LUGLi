#
#   SidebarFeedwise Plugin version 0.1
#   Arrange feeds in a nice html page with a sidebar menu
#   Copyright (C) 2005 - Gutemberg A. Vieira <gutemberg.vieira@gmail.com>
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
#   Based on Feedwise Plugin from Ian Glover <ian@manicai.net>
#   (authorization granted by the author to GPL it)
#

import rawdoglib.plugins

class SidebarFeedwisePlugin:
    def __init__(self):
        last_feed = None

    def startup(self, rawdog, config):
        # Can't work if daysections or timesections is active.
        if config["daysections"]:
            print "SidebarFeedwise Plugin: Turning off daysections configuration option."
            config["daysections"] = 0
        if config["timesections"]:
            print "SidebarFeedwise Plugin: Turning off timesections configuration option."
            config["timesections"] = 0

    # Scan the sorted list of articles and through away old ones to
    # so we don't exceed the configured limit.
    def limit_articles_per_feed(self, rawdog, config, articles):
        feed_counts = {}
        to_remove = []
        for i in range(len(articles)):
            feed = articles[i].feed
            if feed not in feed_counts:
                feed_counts[feed] = 1
            else:
                feed_counts[feed] = feed_counts[feed] + 1
            if feed_counts[feed] > config["articles_per_feed"]:
                # We don't want to from the list whilst iterating through it.
                # So use None as a marker for deletion.
                to_remove.append(articles[i])
        for x in to_remove:
            articles.remove(x)
        
    # Sort the articles by feed and inside each feed by time.
    def sort_by_feed(self, rawdog, config, articles):
        def comparator(lhs, rhs):
            if cmp(lhs.feed, rhs.feed) != 0:
                return cmp(lhs.feed, rhs.feed)
            else:
                # Inverted as we want the most recent first.
                return -cmp(lhs.date, rhs.date)
        articles.sort(comparator)
        self.last_feed = None
        self.limit_articles_per_feed(rawdog, config, articles)
   
    # unescape, used to unescape the feed title (rawdog.get_html_name that it
    # is escape by rawdog and doesn't look good in the menu
    def unescape(self, s):
        """Replace SGML entities by '&', '<' and '>'."""
        s = s.replace("&amp;", "&") # Must be done first!
        s = s.replace("&lt;", "<")
        s = s.replace("&gt;", ">")
        return s

    
    # All the items have been written but we have to close the last feed box
    def items_end(self, rawdog, config, f):
       f.write('</div>')

    
    # Handle the articles_per_feed configuration option
    def handle_config(self, config, name, value):
        if name == "articles_per_feed":
            config["articles_per_feed"] = int(value)
            return 0
        return 1


    def items_heading(self, rawdog, config, f, article, article_dates):
        feed = rawdog.feeds[article.feed]
        if ((self.last_feed == None) or (self.last_feed != feed)): # add the new feed box
            if self.last_feed != None: # it is not the first one, so we must close the previous
                f.write('</div>\n')
            # start the new feed
            f.write("<div name='feed' id='feed" + feed.get_id(config) + "' class='content'>\n")
        self.last_feed = feed
	


    # we build the menu here and pass it as an output bit, so the javascript
    def output_bits(self, rawdog, config, bits): 
        menu = ''
        first_feed_id=''
        for feed in rawdog.feeds.values():
            if first_feed_id == '': # we get the first feed to show it when the page loads
 	       first_feed_id = 'feed' + feed.get_id(config)
            menu = menu +  '<div class="menuitem"> <a href="#" onclick="javascript:show_feed(\'feed' + \
                feed.get_id(config) + '\')"><div id="menuitemtitle' + feed.get_id(config) + '">' + \
                self.unescape(feed.get_html_name(config))  + '</div></a></div>\n'
        bits['menu'] = menu
        bits['first_feed_id'] = first_feed_id

    # corrects the feed title
    def output_item_bits(self, rawdog, config, feed, article, bits):
        bits["feed_title"] = self.unescape(bits["feed_title"])
       


plugin = SidebarFeedwisePlugin()

rawdoglib.plugins.attach_hook( "startup", plugin.startup )
rawdoglib.plugins.attach_hook( "output_sort", plugin.sort_by_feed )
rawdoglib.plugins.attach_hook( "output_items_end", plugin.items_end )
rawdoglib.plugins.attach_hook( "output_item_bits", plugin.output_item_bits )
rawdoglib.plugins.attach_hook( "output_bits", plugin.output_bits )
rawdoglib.plugins.attach_hook( "config_option", plugin.handle_config )
rawdoglib.plugins.attach_hook( "output_items_heading", plugin.items_heading )
