
- Copy sidebarfeedwise.py to your plugins directory (generally
  ~/.rawdog/plugins), and copy sdTemplate.html to the rawdog home (generally
  ~/.rawdog).

- You must set the template option in your config to sdTemplate.html in order
  to work correctly. You can customize it later if you want. It uses the
  default for itemtemplate.

- Also add an option articles_per_feed to your config file, and set it to
  maximum number of articles you want in each feed.

- I have just tested it in Firefox 1.0.3, it may not work well in other
  browsers. If you know javascript/css you know what I am talking about! :)

- Have fun!
   
--
Gutemberg A. Vieira <gutemberg.vieira@gmail.com>

